﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AzureB2C.BlobStorage.Models
{
    public class TnCDetailModel
    {
        public DateTime lastModified { get; set; }
        public int version { get; set; }
    }
}