﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AzureB2C.BlobStorage.Models
{
    public class TranslationModel
    {
        public string ErrorCode { get; set; }
        public Dictionary<string, string> Translations { get; set; }
    }
}