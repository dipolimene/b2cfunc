﻿using AzureB2C.BlobStorage.Models;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace AzureB2C.BlobStorage
{
    public class BlobReader
    {
        public async Task<string> GetAllTransationsAsync(string fileName, string containerName, string storageConnectionString, string language, string errorCode)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            CloudBlobClient client = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = client.GetContainerReference(containerName);

            CloudBlockBlob blockBlob = container.GetBlockBlobReference(fileName);
            using (var memoryStream = new MemoryStream())
            {
                await blockBlob.DownloadToStreamAsync(memoryStream);
                string content = System.Text.Encoding.UTF8.GetString(memoryStream.ToArray());
                var messages = JsonConvert.DeserializeObject<IList<TranslationModel>>(content);

                var translation = messages.FirstOrDefault(p => p.ErrorCode == errorCode);
                var userMassage = translation.Translations[language];

                return userMassage;

            }
        }

        public async Task<TnCDetailModel> GetTnCDateDetails(string fileName, string containerName, string storageConnectionString)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            CloudBlobClient client = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = client.GetContainerReference(containerName);

            CloudBlockBlob blockBlob = container.GetBlockBlobReference(fileName);
            using (var memoryStream = new MemoryStream())
            {
                await blockBlob.DownloadToStreamAsync(memoryStream);
                string content = System.Text.Encoding.UTF8.GetString(memoryStream.ToArray());
                var tncDetails = JsonConvert.DeserializeObject<TnCDetailModel>(content);
                return tncDetails;

            }
        }
    }
}