using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Web.Helpers;
using AzureB2C.BlobStorage;
using AzureB2C.Common;

namespace AzureB2CFunc
{
    public static class PasswordHash
    {
        [FunctionName("PasswordHash")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "user/validate/passwordhash")] HttpRequest req,
            ILogger log)
        {

            dynamic data;
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            data = JsonConvert.DeserializeObject(requestBody);
            var insightModel = JsonConvert.DeserializeObject<InsightModel>(requestBody);

            try
            {
                log.LogInformation("C# HTTP trigger function processed a request.");

                string password = req.Query["password"];
                string hash = req.Query["extension_password_hash"];

                
                log.LogInformation(requestBody);
                var appInsights = new AppInsights(Environment.GetEnvironmentVariable("AppInsightInstrumentationKey", EnvironmentVariableTarget.Process));
                appInsights.LogEvent("AzureInsights PasswordHash API", insightModel);


                password = password ?? data?.password;
                

                hash = hash ?? data?.extension_password_hash;

                string passwordHash = hash.Split(":")[0];
                string salt = hash.Split(":")[1];

                var newhash = Crypto.SHA256(salt + password);

                log.LogInformation("passwordHash: " + passwordHash);
                log.LogInformation("salt: " + salt);
                log.LogInformation("newhash: " + newhash);


                if (newhash.ToLower() == passwordHash.ToLower())
                {
                    return (ActionResult)new OkObjectResult(true);
                }
                else
                {
                    log.LogInformation("Inside else");

                    var fileName = Convert.ToString(Environment.GetEnvironmentVariable("PasswordTranslationFileName", EnvironmentVariableTarget.Process));
                    var containerName = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageContainerName", EnvironmentVariableTarget.Process));
                    var connectionString = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageConnectionString", EnvironmentVariableTarget.Process));

                    log.LogInformation("fileName: " + fileName);
                    log.LogInformation("containerName: " + containerName);
                    log.LogInformation("connectionString: " + connectionString);

                    BlobReader blobReader = new BlobReader();

                    string userMessage = await blobReader.GetAllTransationsAsync(fileName, containerName, connectionString, data.clientLanguage.ToString(), "invalidPassword");


                    return new BadRequestObjectResult(new PassResponseContent
                    {
                        userMessage = userMessage,
                        //userMessage = "Password is incorrect",
                        version = "1.0.0",
                        status = 409,
                        code = "API12345",
                        requestId = "50f0bd91-2ff4-4b8f-828f-00f170519ddb",
                        developerMessage = "Verbose description of problem and how to fix it.",
                        moreInfo = "https://restapi/error/API12345/moreinfo"
                    });
                }
            }
            catch (Exception ex)
            {
                log.LogInformation("Error: " + ex);

                var fileName = Convert.ToString(Environment.GetEnvironmentVariable("PasswordTranslationFileName", EnvironmentVariableTarget.Process));
                var containerName = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageContainerName", EnvironmentVariableTarget.Process));
                var connectionString = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageConnectionString", EnvironmentVariableTarget.Process));

                log.LogInformation("fileName: " + fileName);
                log.LogInformation("containerName: " + containerName);
                log.LogInformation("connectionString: " + connectionString);

                BlobReader blobReader = new BlobReader();

                string userMessage = await blobReader.GetAllTransationsAsync(fileName, containerName, connectionString, data.clientLanguage.ToString() ?? "en-US", "passwordhash-match-service.generic-exception");

                return new BadRequestObjectResult(new PassResponseContent
                {
                    userMessage = userMessage,
                    //userMessage = "Sorry, something happened unexpectedly, please try again later.",
                    version = "1.0.0",
                    status = 409,
                    code = "API12345",
                    requestId = "50f0bd91-2ff4-4b8f-828f-00f170519ddb",
                    developerMessage = "Verbose description of problem and how to fix it.",
                    moreInfo = "https://restapi/error/API12345/moreinfo"
                });
            }
        }
    }
}

public class PassResponseContent
{
    public string version { get; set; }
    public int status { get; set; }
    public string code { get; set; }
    public string userMessage { get; set; }
    public string developerMessage { get; set; }
    public string requestId { get; set; }
    public string moreInfo { get; set; }
}