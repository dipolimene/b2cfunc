using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AzureB2CFunc
{
    public static class Register
    {
        //[FunctionName("ServiceBusOutput")]
        //[return: ServiceBus("onboarding", Connection = "ServiceBusConnection")]
        //public static string ServiceBusOutput(
        //    [HttpTrigger(AuthorizationLevel.Function, "post", Route = "servicebus/notification")] dynamic input)
        //{
        //    return input.ToString();
        //}

        [FunctionName("ServiceBusOutput")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "servicebus/notification")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            return new OkResult();
        }
    }
}
