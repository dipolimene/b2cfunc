using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using AzureB2CFunc.Models;
using AzureB2C.BlobStorage;
using System.Linq;
using AzureB2C.Common;

namespace AzureB2CFunc
{
    public static class TaxIdAndPOCIdValidator
    {
        [FunctionName("TaxIdAndPOCIdValidator")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "user/validate/pocandtax")] HttpRequest req,
            ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);

            try
            {
                log.LogInformation("C# HTTP trigger function processed a request.");
                string value = "";
                string accountId = "";
                string country = "";
                log.LogInformation(requestBody);
                value = data.extension_value;
                accountId = data.extension_accountid;
                country = data.country;
                var insightModel = JsonConvert.DeserializeObject<InsightModel>(requestBody);
                var appInsights = new AppInsights(Environment.GetEnvironmentVariable("AppInsightInstrumentationKey", EnvironmentVariableTarget.Process));
                appInsights.LogEvent("AzureInsights TaxId And POCId Validator API", insightModel);

                using (var httpClient = new HttpClient())
                {

                    var token = $"Bearer { Convert.ToString(Environment.GetEnvironmentVariable("ABIServiceAccessToken", EnvironmentVariableTarget.Process)) }";
                    using (var request = new HttpRequestMessage(new HttpMethod("POST"), Convert.ToString(Environment.GetEnvironmentVariable("ABIAccountBsChallengeAPI", EnvironmentVariableTarget.Process))))
                    {
                        request.Headers.TryAddWithoutValidation("accept", "*/*");
                        request.Headers.TryAddWithoutValidation("Authorization", token);
                        request.Headers.TryAddWithoutValidation("country", country ?? Convert.ToString(Environment.GetEnvironmentVariable("ABITaxPOCCountryName", EnvironmentVariableTarget.Process)));
                        request.Headers.TryAddWithoutValidation("requestTraceId", insightModel.RequestTraceId ?? Guid.NewGuid().ToString());

                        if (!String.IsNullOrWhiteSpace(value) && !String.IsNullOrWhiteSpace(accountId))
                        {
                            request.Content = new StringContent("{ \"accountId\": \"" + accountId + "\", \"value\": \"" + value + "\"}");
                        }
                        else
                        {
                            log.LogInformation("Inside else");

                            var fileName = Convert.ToString(Environment.GetEnvironmentVariable("OnBoardingLocalisationFilename", EnvironmentVariableTarget.Process));
                            var containerName = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageContainerName", EnvironmentVariableTarget.Process));
                            var connectionString = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageConnectionString", EnvironmentVariableTarget.Process));
                            BlobReader blobReader = new BlobReader();
                            var userMessage = await blobReader.GetAllTransationsAsync(fileName, containerName, connectionString, data.clientLanguage.ToString(), "account-business-service.required-field");

                            if (String.IsNullOrWhiteSpace(value))
                            {
                                userMessage += " value.";
                            }
                            else if(String.IsNullOrWhiteSpace(accountId))
                            {
                                userMessage += " accountId.";
                            }

                            return new BadRequestObjectResult(new ResponseContent
                            {
                                userMessage = userMessage,
                                version = "1.0.0",
                                status = 409,
                                code = "API12345",
                                requestId = "50f0bd91-2ff4-4b8f-828f-00f170519ddb",
                                developerMessage = "Verbose description of problem and how to fix it.",
                                moreInfo = "https://restapi/error/API12345/moreinfo"
                            });
                        }

                        request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        var response = await httpClient.SendAsync(request);

                        if (response.IsSuccessStatusCode)
                        {

                            log.LogInformation(response.ToString());
                            log.LogInformation(response.Content.ReadAsStringAsync().Result);
                            return (ActionResult)new OkObjectResult(true);
                        }
                        else
                        {
                            var responseObject = await response.Content.ReadAsAsync<APIErrorResposeModel>();

                            var fileName = Convert.ToString(Environment.GetEnvironmentVariable("OnBoardingLocalisationFilename", EnvironmentVariableTarget.Process));
                            var containerName = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageContainerName", EnvironmentVariableTarget.Process));
                            var connectionString = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageConnectionString", EnvironmentVariableTarget.Process));
                            BlobReader blobReader = new BlobReader();
                            var userMessage = await blobReader.GetAllTransationsAsync(fileName, containerName, connectionString, data.clientLanguage.ToString(), responseObject.details.FirstOrDefault().code);

                            if (responseObject.details.FirstOrDefault().code == "account-business-service.required-field")
                            {
                                userMessage += (" " + responseObject.details.FirstOrDefault().attribute + ".");
                            }


                            return new BadRequestObjectResult(new ResponseContent
                            {
                                userMessage = userMessage,
                                //userMessage = responseObject.message,
                                version = "1.0.0",
                                status = 409,
                                code = "API12345",
                                requestId = "50f0bd91-2ff4-4b8f-828f-00f170519ddb",
                                developerMessage = "Verbose description of problem and how to fix it.",
                                moreInfo = "https://restapi/error/API12345/moreinfo"
                            });
                        }
                    }
                }
            }
            catch (Exception)
            {
                var fileName = Convert.ToString(Environment.GetEnvironmentVariable("OnBoardingLocalisationFilename", EnvironmentVariableTarget.Process));
                var containerName = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageContainerName", EnvironmentVariableTarget.Process));
                var connectionString = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageConnectionString", EnvironmentVariableTarget.Process));
                BlobReader blobReader = new BlobReader();
                var userMessage = await blobReader.GetAllTransationsAsync(fileName, containerName, connectionString, data.clientLanguage.ToString(), "account-business-service.generic-exception");

                return new BadRequestObjectResult(new ResponseContent
                {
                    userMessage = userMessage,
                    //userMessage = "Something happened unexpectedly, please try again later",
                    version = "1.0.0",
                    status = 409,
                    code = "API12345",
                    requestId = "50f0bd91-2ff4-4b8f-828f-00f170519ddb",
                    developerMessage = "Verbose description of problem and how to fix it.",
                    moreInfo = "https://restapi/error/API12345/moreinfo"
                });
            }
        }
    }
}