using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using AzureB2C.Job;
using AzureB2C.TableStorage;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace AzureB2CFunc
{
    public static class MigrationFileProcessor
    {
        [FunctionName("MigrationFileProcessor")]
        public static void Run([BlobTrigger("migration-file/{name}", Connection = "DataBlobConnectionString")]Stream myBlob, string name, ILogger log)
        {
            log.LogInformation($"C# Blob trigger function Processed blob\n Name:{name} \n Size: {myBlob.Length} Bytes");

            var migrationJobStatus = new MigrationJobStatus(new Dictionary<string, string>()
            {
                { "DataAzureTableStorageConnectionString",Environment.GetEnvironmentVariable("DataAzureTableStorageConnectionString", EnvironmentVariableTarget.Process) }
            });

            try
            {

                Task.Run(() =>
                {
                    var worker = new Worker();

                    try
                    {
                        worker = new Worker()
                        {
                            DataAzureTableStorageConnectionString = Environment.GetEnvironmentVariable("DataAzureTableStorageConnectionString", EnvironmentVariableTarget.Process),
                            FileName = name,
                            FilePath = $"{Environment.GetEnvironmentVariable("BlobStoragePath", EnvironmentVariableTarget.Process)}/migration-files/{name}",
                            BlobStream = myBlob,
                            ClientId = Environment.GetEnvironmentVariable("ClientId", EnvironmentVariableTarget.Process),
                            ClientSecret = Environment.GetEnvironmentVariable("ClientSecret", EnvironmentVariableTarget.Process),
                            TenantUrl = Environment.GetEnvironmentVariable("TenantUrl", EnvironmentVariableTarget.Process),
                            MigrationAppId = Environment.GetEnvironmentVariable("MigrationAppId", EnvironmentVariableTarget.Process)
                        };

                        worker.Run();
                    }
                    catch (Exception ex)
                    {
                        log.LogInformation($"exception {ex.Message}");
                        migrationJobStatus.UpdateMigrationJobStatus(worker.MigrationJobStatusId, "Error", $"Message :- { ex.Message} \n Inner Exception:- { ex.InnerException}");
                    }
                });
            }
            catch (Exception ex)
            {
                log.LogInformation($"exception {ex.Message}");
            }
        }


    }
}
