using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace AzureB2CFunc
{
    public static class User
    {
        [FunctionName("User")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "user/validate/username")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string userName = req.Query["userName"];
            var userNameList = new List<string>() { "abc","123","xyz" };

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            userName = userName ?? data?.userName;

            if (userName != null)
            {
                if (userNameList.Contains(userName.ToLowerInvariant()))
                {
                    return new BadRequestObjectResult(new ResponseContent() { version = "v1", status = 400, userMessage = "Sorry, User Name already taken" });
                }
                return new OkResult();
            }

            return new BadRequestObjectResult(new ResponseContent() { version = "v1", status = 400, userMessage = "Please pass a userName on the query string or in the request body" });
        }
    }


    public class ResponseContent
    {
        public string version { get; set; }
        public int status { get; set; }
        public string userMessage { get; set; }
        public string code { get; set; }
        public string developerMessage { get; set; }
        public string requestId { get; set; }
        public string moreInfo { get; set; }
    }
}
