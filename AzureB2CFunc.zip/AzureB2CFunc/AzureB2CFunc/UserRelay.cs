using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using AzureB2C.Job.Tools;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using AzureB2CFunc.Models;
using System.Net;
using System.Text;
using AzureB2C.BlobStorage;
using AzureB2C.Common;

namespace AzureB2CFunc
{
    public static class UserRelay
    {
        [FunctionName("UserRelay")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "user/relay")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var data = JsonConvert.DeserializeObject<FuncRequest>(requestBody);

            try
            {
                log.LogInformation(requestBody);

                var insightModel = JsonConvert.DeserializeObject<InsightModel>(requestBody);
                var appInsights = new AppInsights(Environment.GetEnvironmentVariable("AppInsightInstrumentationKey", EnvironmentVariableTarget.Process));
                appInsights.LogEvent("AzureInsights UserRelay API", insightModel);

                var token = $"Bearer { Convert.ToString(Environment.GetEnvironmentVariable("ABIServiceAccessToken", EnvironmentVariableTarget.Process)) }";

                using (var client = new HttpClient())
                {
                    if (!String.IsNullOrEmpty(data.accounts))
                    {
                        data.accounts = data.accounts.Replace("[", String.Empty).Replace("]", String.Empty);
                    }
                    var userRelayRequest = new UserRelayRequest()
                    {
                        firstName = data.firstName,
                        lastName = data.lastName,
                        password = data.password,
                        accounts = !String.IsNullOrEmpty(data.accounts) ? data.accounts.Split(',').ToList() : new List<string>()
                    };

                    if (!String.IsNullOrWhiteSpace(data.email))
                    {
                        userRelayRequest.email = data.email;
                        userRelayRequest.contactVerificationType.Add("EMAIL");
                    }

                    if (!String.IsNullOrWhiteSpace(data.phone))
                    {
                        userRelayRequest.phone = data.phone;
                        userRelayRequest.contactVerificationType.Add("CELLPHONE");
                    }

                    var httpRequestMessage = new HttpRequestMessage
                    {
                        Method = HttpMethod.Put,
                        RequestUri = new Uri(Convert.ToString(Environment.GetEnvironmentVariable("ABIUserRelayAPI", EnvironmentVariableTarget.Process)) + data.userId),
                        Headers = {
                        { HttpRequestHeader.Authorization.ToString(), token },
                        { HttpRequestHeader.ContentType.ToString(), "application/json" },
                        { "requestTraceId", insightModel.RequestTraceId ?? Guid.NewGuid().ToString() }
                      },
                        Content = new StringContent(JsonConvert.SerializeObject(userRelayRequest), Encoding.UTF8,
                                    "application/json")
                    };

                    if (!String.IsNullOrWhiteSpace(data.country))
                    {
                        httpRequestMessage.Headers.Add("country", data.country);
                    }
                    else
                    {
                        httpRequestMessage.Headers.Add("country", Convert.ToString(Environment.GetEnvironmentVariable("ABIUserRelayCountryName", EnvironmentVariableTarget.Process)));
                    }

                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = await client.SendAsync(httpRequestMessage);

                    if (response.IsSuccessStatusCode)
                    {
                        log.LogInformation(response.ToString());
                        log.LogInformation(await response.Content.ReadAsStringAsync());
                        return (ActionResult)new OkObjectResult(true);
                    }
                    else
                    {
                        var responseObject = await response.Content.ReadAsAsync<APIErrorResposeModel>();

                        var fileName = Convert.ToString(Environment.GetEnvironmentVariable("UserRelayLocalisationFilename", EnvironmentVariableTarget.Process));
                        var containerName = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageContainerName", EnvironmentVariableTarget.Process));
                        var connectionString = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageConnectionString", EnvironmentVariableTarget.Process));

                        BlobReader blobReader = new BlobReader();
                        var userMessage = await blobReader.GetAllTransationsAsync(fileName, containerName, connectionString, data.clientLanguage, responseObject.details.FirstOrDefault().code);

                        if (responseObject.details.FirstOrDefault().code == "user-relay-service.required-field")
                        {
                            userMessage += (" " + responseObject.details.FirstOrDefault().attribute + ".");
                        }

                        return new BadRequestObjectResult(new ResponseContentModel
                        {
                            userMessage = userMessage,
                            //userMessage = responseObject.details.FirstOrDefault().message + ": " + responseObject.details.FirstOrDefault().attribute,
                            version = "1.0.0",
                            status = 409,
                            code = "API12345",
                            requestId = "50f0bd91-2ff4-4b8f-828f-00f170519ddb",
                            developerMessage = "Verbose description of problem and how to fix it.",
                            moreInfo = "https://restapi/error/API12345/moreinfo"
                        });
                    }
                }
            }
            catch (Exception ex)
            {

                var fileName = Convert.ToString(Environment.GetEnvironmentVariable("UserRelayLocalisationFilename", EnvironmentVariableTarget.Process));
                var containerName = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageContainerName", EnvironmentVariableTarget.Process));
                var connectionString = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageConnectionString", EnvironmentVariableTarget.Process));

                BlobReader blobReader = new BlobReader();
                var userMessage = await blobReader.GetAllTransationsAsync(fileName, containerName, connectionString, data.clientLanguage, "user-relay-service.generic-exception");

                return new BadRequestObjectResult(new ResponseContent
                {
                    userMessage = userMessage,
                    //userMessage = ex.Message,
                    version = "1.0.0",
                    status = 409,
                    code = "API12345",
                    requestId = "50f0bd91-2ff4-4b8f-828f-00f170519ddb",
                    developerMessage = "Verbose description of problem and how to fix it.",
                    moreInfo = "https://restapi/error/API12345/moreinfo"
                });
            }
        }
    }

    public class UserRelayRequest
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public List<string> contactVerificationType { get; set; }
        public string password { get; set; }
        public List<string> accounts { get; set; }

        public UserRelayRequest()
        {
            accounts = new List<string>();
            contactVerificationType = new List<string>();
        }
    }

    public class FuncRequest
    {
        public string userId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public string password { get; set; }
        public string accounts { get; set; }
        public string country { get; set; }
        public string clientLanguage { get; set; }
    }
}