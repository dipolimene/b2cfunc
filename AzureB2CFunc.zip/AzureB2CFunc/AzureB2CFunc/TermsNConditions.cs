using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using AzureB2C.BlobStorage;
using AzureB2C.Common;

namespace AzureB2CFunc
{
    public static class TermsNConditions
    {
        [FunctionName("TermsNConditions")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "system/termsnconditions")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger TermsNConditions function.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var insightModel = JsonConvert.DeserializeObject<InsightModel>(requestBody);
            var appInsights = new AppInsights(Environment.GetEnvironmentVariable("AppInsightInstrumentationKey", EnvironmentVariableTarget.Process));
            appInsights.LogEvent("AzureInsights Terms N Conditions API", insightModel);

            var fileName = Convert.ToString(Environment.GetEnvironmentVariable("TermsAndConditionsLatestFileName", EnvironmentVariableTarget.Process));
            var containerName = Convert.ToString(Environment.GetEnvironmentVariable("TermsAndConditionsLatestFileStorageContainerName", EnvironmentVariableTarget.Process));
            var connectionString = Convert.ToString(Environment.GetEnvironmentVariable("TermsAndConditionsLatestFileStorageConnectionString", EnvironmentVariableTarget.Process));
            BlobReader blobReader = new BlobReader();
            var tnCDetail = await blobReader.GetTnCDateDetails(fileName, containerName, connectionString);

            return (ActionResult)new OkObjectResult(new
            TermsNConditionsResponseModel()
            {
                extension_termsOfDateTime = tnCDetail.lastModified,
                extension_termsOfUseConsentDateTime = Convert.ToDateTime(Environment.GetEnvironmentVariable("TermsOfUseConsentDateTime", EnvironmentVariableTarget.Process))
            });
        }
    }

    public class TermsNConditionsResponseModel
    {
        public DateTime extension_termsOfDateTime { get; set; }
        public DateTime extension_termsOfUseConsentDateTime { get; set; }
    }
}
