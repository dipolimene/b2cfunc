﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AzureB2CFunc.Models
{

    public class Detail
    {
        public string code { get; set; }
        public string message { get; set; }
        public string attribute { get; set; }
    }

    public class APIErrorResposeModel
    {
        public string message { get; set; }
        public List<Detail> details { get; set; }
    }
}