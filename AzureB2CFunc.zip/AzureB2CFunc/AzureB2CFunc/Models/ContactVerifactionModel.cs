﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AzureB2CFunc.Models
{
    public class ContactVerifactionModel
    {
        public string clientLanguage { get; set; }
        public string countryCode { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string readonlyEmail { get; set; }
        public string otp { get; set; }
    }
}