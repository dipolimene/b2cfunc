﻿namespace AzureB2CFunc.Models
{
    public class OutputClaimsModel
    {
        public string extension_accountids { get; set; }
    }
}