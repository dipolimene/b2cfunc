﻿using System;

namespace AzureB2CFunc.Models
{
    public class OTPAPIResponse
    {
        public int secondsToRetry { get; set; }
        public DateTime expirationDate { get; set; }
        public string type { get; set; }
        public string value { get; set; }
        public string emailValue { get; set; }
        public string phoneValue { get; set; }
    }
}