﻿namespace AzureB2CFunc.Models
{
    public class ResponseContentModel
    {
        public string version { get; set; }
        public int status { get; set; }
        public string userMessage { get; set; }
        public string code { get; set; }
        public string developerMessage { get; set; }
        public string requestId { get; set; }
        public string moreInfo { get; set; }
    }
}