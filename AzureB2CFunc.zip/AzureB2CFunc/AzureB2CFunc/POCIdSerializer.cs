﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using AzureB2CFunc.Models;
using System.IO;
using Newtonsoft.Json;
using System;
using System.Linq;
using AzureB2C.BlobStorage;
using AzureB2C.Common;

namespace AzureB2CFunc
{
    public class POCIdSerializer
    {
        [FunctionName("POCIdSerializer")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "user/serializepoc")] HttpRequest req,
            ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);

            try
            {
                log.LogInformation("C# HTTP trigger function processed a request.");

                string accountId = "";
                string accountIds = "";

                log.LogInformation(requestBody);
                var insightModel = JsonConvert.DeserializeObject<InsightModel>(requestBody);
                var appInsights = new AppInsights(Environment.GetEnvironmentVariable("AppInsightInstrumentationKey", EnvironmentVariableTarget.Process));
                appInsights.LogEvent("AzureInsights POC Id Serializer API", insightModel);

                accountId = data.extension_accountid;
                accountIds = data.extension_accountids;
                if (accountIds != "")
                {
                    accountIds = accountIds.Replace("[", "");
                    accountIds = accountIds.Replace("]", "");
                    var list = accountIds.Split(',').ToList();
                    if (!list.Exists(p => p.ToLower() == accountId.ToLower()))
                    {
                        accountIds += ("," + accountId);
                    }
                    else
                    {

                        var fileName = Convert.ToString(Environment.GetEnvironmentVariable("AccountIdDuplicateFilename", EnvironmentVariableTarget.Process));
                        var containerName = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageContainerName", EnvironmentVariableTarget.Process));
                        var connectionString = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageConnectionString", EnvironmentVariableTarget.Process));

                        BlobReader blobReader = new BlobReader();
                        var userMessage = await blobReader.GetAllTransationsAsync(fileName, containerName, connectionString, data.clientLanguage.ToString(), "account-id-service.duplicate-id");

                        return new BadRequestObjectResult(new ResponseContent
                        {
                            userMessage = userMessage,
                            //userMessage = "{field-id:extension_accountid}This account has already been associated.{field-id:extension_value}",
                            version = "1.0.0",
                            status = 409,
                            code = "API12345",
                            requestId = "50f0bd91-2ff4-4b8f-828f-00f170519ddb",
                            developerMessage = "Verbose description of problem and how to fix it.",
                            moreInfo = "https://restapi/error/API12345/moreinfo"
                        });
                    }
                }
                else
                {
                    accountIds = accountId;
                }


                OutputClaimsModel outputClaims = new OutputClaimsModel();
                outputClaims.extension_accountids = "[" + accountIds + "]";

                return (ActionResult)new OkObjectResult(outputClaims);
            }
            catch (Exception ex)
            {
                log.LogInformation(ex.ToString());

                var fileName = Convert.ToString(Environment.GetEnvironmentVariable("AccountIdDuplicateFilename", EnvironmentVariableTarget.Process));
                var containerName = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageContainerName", EnvironmentVariableTarget.Process));
                var connectionString = Convert.ToString(Environment.GetEnvironmentVariable("TranslationStorageConnectionString", EnvironmentVariableTarget.Process));

                BlobReader blobReader = new BlobReader();
                var userMessage = await blobReader.GetAllTransationsAsync(fileName, containerName, connectionString, data.clientLanguage.ToString(), "account-id-service.generic-exception");

                return new BadRequestObjectResult(new ResponseContent
                {
                    userMessage = userMessage,
                    //userMessage = "Something happened unexpectedly, please try again later",
                    version = "1.0.0",
                    status = 409,
                    code = "API12345",
                    requestId = "50f0bd91-2ff4-4b8f-828f-00f170519ddb",
                    developerMessage = "Verbose description of problem and how to fix it.",
                    moreInfo = "https://restapi/error/API12345/moreinfo"
                });
            }
        }
    }
}