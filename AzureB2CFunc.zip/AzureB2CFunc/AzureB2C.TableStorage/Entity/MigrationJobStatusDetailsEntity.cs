﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace AzureB2C.TableStorage.Entity
{
    public class MigrationJobStatusDetailsEntity : TableEntity
    {
        public MigrationJobStatusDetailsEntity()
        {
            this.PartitionKey = "DR";
            this.RowKey = Guid.NewGuid().ToString();
        }

        public string MigrationJobStatusId { get; set; }

        public string GraphInputInfo { get; set; }

        public string GraphOutputInfo { get; set; }

        public string ObjectId { get; set; }

        public string MagentoCustomerId { get; set; }

        public string Status { get; set; }

        public string ErrorMessage { get; set; }

        public string IsPhoneNormalized { get; set; }

        public string PhoneNumberFormat { get; set; }
    }
}
