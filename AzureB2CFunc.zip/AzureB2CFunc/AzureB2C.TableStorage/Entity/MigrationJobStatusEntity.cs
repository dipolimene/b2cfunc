﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace AzureB2C.TableStorage.Entity
{
    public class MigrationJobStatusEntity : TableEntity
    {
        public MigrationJobStatusEntity()
        {
            this.PartitionKey = "DR";
            this.RowKey = Guid.NewGuid().ToString();
        }

        public MigrationJobStatusEntity(string migrationJobStatusId)
        {
            this.PartitionKey = "DR";
            this.RowKey = migrationJobStatusId;
        }

        public string FileName { get; set; }

        public string FileBlobPath { get; set; }

        public string Status { get; set; }

        public string ErrorMessage { get; set; }
    }
}
