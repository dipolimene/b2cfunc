﻿using AzureB2C.TableStorage.Entity;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;

namespace AzureB2C.TableStorage
{
    public class MigrationJobStatusDetails
    {
        CloudStorageAccount storageAccount = null;
        CloudTableClient tableClient = null;
        CloudTable table = null;

        public MigrationJobStatusDetails(Dictionary<string, string> parameters)
        {
            storageAccount = CloudStorageAccount.Parse(parameters["DataAzureTableStorageConnectionString"]);
            tableClient = storageAccount.CreateCloudTableClient();
            table = tableClient.GetTableReference("MigrationJobStatusDetails");
        }

        public void CreateMigrationJobStatusDetails(string migrationJobStatusId,
            string graphInputInfo,
            string graphOutputInfo,
            string status,
            string objectId = "",
            string magentoCustomerId = "",
            string errorMessage = "",
            string isPhoneNormalized = "false",
            string phoneNumberFormat = "")
        {
            var migrationJobStatusEntity = new MigrationJobStatusDetailsEntity()
            {
                MigrationJobStatusId = migrationJobStatusId,
                GraphInputInfo = graphInputInfo,
                GraphOutputInfo = graphOutputInfo,
                ObjectId = objectId,
                MagentoCustomerId = magentoCustomerId,
                Status = status,
                ErrorMessage = errorMessage,
                IsPhoneNormalized = isPhoneNormalized,
                PhoneNumberFormat = phoneNumberFormat
            };

            TableOperation insertOperation = TableOperation.Insert(migrationJobStatusEntity);

            // Execute the insert operation.
            table.ExecuteAsync(insertOperation);
        }
    }
}
