﻿using AzureB2C.TableStorage.Entity;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;

namespace AzureB2C.TableStorage
{
    public class MigrationJobStatus
    {
        CloudStorageAccount storageAccount = null;
        CloudTableClient tableClient = null;
        CloudTable table = null;

        public MigrationJobStatus(Dictionary<string, string> parameters)
        {
            storageAccount = CloudStorageAccount.Parse(parameters["DataAzureTableStorageConnectionString"]);
            tableClient = storageAccount.CreateCloudTableClient();
            table = tableClient.GetTableReference("MigrationJobStatus");
        }

        public string CreateMigrationJobStatus(string fileName, string filePath, string statusName)
        {
            var migrationJobStatusEntity = new MigrationJobStatusEntity()
            {
                FileName = fileName,
                FileBlobPath = filePath,
                Status = statusName
            };

            TableOperation insertOperation = TableOperation.Insert(migrationJobStatusEntity);

            // Execute the insert operation.
            table.ExecuteAsync(insertOperation);

            return migrationJobStatusEntity.RowKey;
        }

        public void UpdateMigrationJobStatus(string migrationJobStatusId, string statusName, string errorMessage = "")
        {
            var migrationJobStatusEntity = new MigrationJobStatusEntity(migrationJobStatusId)
            {
                Status = statusName,
                ErrorMessage = errorMessage
            };

            TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(migrationJobStatusEntity);

            // Execute the insert operation.
            table.ExecuteAsync(insertOrMergeOperation);
        }
    }
}
