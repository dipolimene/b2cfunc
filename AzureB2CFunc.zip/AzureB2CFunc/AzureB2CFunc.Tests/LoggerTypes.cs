﻿namespace AzureB2CFunc.Tests
{
    public enum LoggerTypes
    {
        Null,
        List
    }
}