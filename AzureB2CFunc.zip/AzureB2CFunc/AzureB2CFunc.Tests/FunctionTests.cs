using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using Xunit;

namespace AzureB2CFunc.Tests
{
    public class FunctionTests
    {
        private readonly ILogger logger = TestFactory.CreateLogger();

        [Theory]
        [MemberData(nameof(TestFactory.PasswordHashData), MemberType = typeof(TestFactory))]
        public async void PasswordHash_Test(string queryStringValue)
        {
            var testValues = queryStringValue.Split(",");
            var query = new Dictionary<String, StringValues>();
            query.TryAdd(testValues[0], testValues[1]);
            query.TryAdd(testValues[2], testValues[3]);
            var body = "";//"{\"password\":\"SomethingDigital123\",\"extension_password_hash\":\"2fdf6056eadb7412942bbcc8a39550be328aaff07366ddbb6a9db7f375bc2d72:KFdCLS0Xo7QbTsozU5gBlsrOEjdm854t:1\"}";
            var request = TestFactory.CreateHttpRequest(query, body);
            var response = (OkObjectResult)await PasswordHash.Run(request, logger);
            Assert.Equal(true, response.Value);
        }



        [Theory]
        [MemberData(nameof(TestFactory.AccountAndTaxIdData), MemberType = typeof(TestFactory))]
        public async void TaxIdAndPOCIdValidator_test(string queryStringValue)
        {
            //var testValues = queryStringValue.Split(",");
            var query = new Dictionary<String, StringValues>();
            var body = queryStringValue;
            var request = TestFactory.CreateHttpRequest(query, body);
            var response = (OkObjectResult)await TaxIdAndPOCIdValidator.Run(request, logger);
            Assert.Equal(true, response.Value);
        }
    }
}