﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Primitives;
using Moq;
using System;
using System.Collections.Generic;
using System.IO;

namespace AzureB2CFunc.Tests
{
    public class TestFactory
    {
        public static IEnumerable<object[]> PasswordHashData()
        {
            return new List<object[]>
            {
                new object[] { "password,SomethingDigital123,extension_password_hash,2fdf6056eadb7412942bbcc8a39550be328aaff07366ddbb6a9db7f375bc2d72:KFdCLS0Xo7QbTsozU5gBlsrOEjdm854t:1" }
                //,new object[] { "password,P@ssw0rd,extension_password_hash,2fdf6056eadb7412942bbcc8a39550be328aaff07366ddbb6a9db7f375bc2d72:KFdCLS0Xo7QbTsozU5gBlsrOEjdm854t:1" }
            };
        }

        public static IEnumerable<object[]> AccountAndTaxIdData()
        {
            return new List<object[]>
            {
                new object[] { "{\"extension_value\":\"00108100983\",\"extension_accountid\":\"0000100004\",\"country\":\"DO\",\"RequestTraceId\":\"Test123\"}" }
            };
        }

        private static Dictionary<string, StringValues> CreateDictionary(string key, string value)
        {
            var qs = new Dictionary<string, StringValues>
            {
                { key, value }
            };
            return qs;
        }

        public static HttpRequest CreateHttpRequest(Dictionary<String, StringValues> query, string body)
        {
            var reqMock = new Mock<HttpRequest>();

            reqMock.Setup(req => req.Query).Returns(new QueryCollection(query));
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.Write(body);
            writer.Flush();
            stream.Position = 0;
            reqMock.Setup(req => req.Body).Returns(stream);
            return (HttpRequest)reqMock.Object;
        }

        public static DefaultHttpRequest CreateHttpRequest(Dictionary<String, StringValues> query)
        {
            var request = new DefaultHttpRequest(new DefaultHttpContext())
            {
                Query = new QueryCollection(query)
            };
            return request;
        }


        public static ILogger CreateLogger(LoggerTypes type = LoggerTypes.Null)
        {
            ILogger logger;

            if (type == LoggerTypes.List)
            {
                logger = new ListLogger();
            }
            else
            {
                logger = NullLoggerFactory.Instance.CreateLogger("Null Logger");
            }

            return logger;
        }
    }
}