using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System;
using System.Text;
using System.Threading;

namespace MockPolicyTest
{
    [TestFixture]
    public class SignupMock
    {
        private IWebDriver driver;
        private StringBuilder verificationErrors;
        private string baseURL;
        private bool acceptNextAlert = true;

        [SetUp]
        public void SetupTest()
        {
            FirefoxOptions options = new FirefoxOptions();
            options.BrowserExecutableLocation = (@"C:\Program Files (x86)\Mozilla Firefox\firefox.exe"); //This is the location where you have installed Firefox on your machine

            driver = new FirefoxDriver(options);
            baseURL = "https://www.google.com/";
            verificationErrors = new StringBuilder();
        }

        [TearDown]
        public void TeardownTest()
        {
            try
            {
                //driver.Quit();
            }
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
            Assert.AreEqual("", verificationErrors.ToString());
        }

        [Test]
        public void TheSignupMockTest()
        {
            driver.Navigate().GoToUrl("https://b2biamgbusdev.b2clogin.com/b2biamgbusdev.onmicrosoft.com/oauth2/v2.0/authorize?p=B2C_1A_AB2CSIGNUP_DR_MOCK&client_id=29a695d2-2642-4c0b-a1d4-6e6e4e09c5b4&nonce=defaultNonce&redirect_uri=https%3A%2F%2Fjwt.ms&scope=openid&response_type=id_token&prompt=login");
            driver.FindElement(By.Id("email")).Click();
            driver.FindElement(By.Id("email")).Clear();
            driver.FindElement(By.Id("email")).SendKeys("anujz@yopmail.com");
            driver.FindElement(By.Id("continue")).Click();
            IsElementPresent(driver, "otp");
            driver.FindElement(By.Id("otp")).Click();
            driver.FindElement(By.Id("otp")).Clear();
            driver.FindElement(By.Id("otp")).SendKeys("12344");
            driver.FindElement(By.Id("continue")).Click();
            IsElementPresent(driver, "givenName");

            driver.FindElement(By.Id("givenName")).Click();
            driver.FindElement(By.Id("givenName")).Clear();
            driver.FindElement(By.Id("givenName")).SendKeys("Anuj");
            driver.FindElement(By.Id("surname")).Clear();
            driver.FindElement(By.Id("surname")).SendKeys("Anuj");
            driver.FindElement(By.Id("continue")).Click();
            IsElementPresent(driver, "newPassword");

            driver.FindElement(By.Id("newPassword")).Clear();
            driver.FindElement(By.Id("newPassword")).Clear();
            driver.FindElement(By.Id("newPassword")).SendKeys("P@ssw0rd");
            driver.FindElement(By.Id("continue")).Click();
        }
        private bool IsElementPresent(By by)
        {
            try
            {
                driver.FindElement(by);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        private bool IsAlertPresent()
        {
            try
            {
                driver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        private string CloseAlertAndGetItsText()
        {
            try
            {
                IAlert alert = driver.SwitchTo().Alert();
                string alertText = alert.Text;
                if (acceptNextAlert)
                {
                    alert.Accept();
                }
                else
                {
                    alert.Dismiss();
                }
                return alertText;
            }
            finally
            {
                acceptNextAlert = true;
            }
        }


        private void IsElementPresent(IWebDriver driver, string id)
        {
            WebDriverWait waitForElement = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
            waitForElement.Until(ExpectedConditions.ElementIsVisible(By.Id(id)));
        }
    }
}