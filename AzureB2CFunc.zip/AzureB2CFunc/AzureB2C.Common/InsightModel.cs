﻿namespace AzureB2C.Common
{
    public class InsightModel
    {
        public string RequestTraceId { get; set; }
        public string RequestId { get; set; }
        public string Culture { get; set; }
        public string FederatedUser { get; set; }
        public string ParsedDomain { get; set; }
        public string CultureLanguageName { get; set; }
        public string CultureLCID { get; set; }
        public string CultureRegionName { get; set; }
        public string CultureRFC5646 { get; set; }
        public string PolicyId { get; set; }
        public string PolicyRelyingPartyTenantId { get; set; }
        public string PolicyTenantstringId { get; set; }
        public string PolicyTrustFrameworkTenantId { get; set; }
        public string OIDCAuthenticationContextReferences { get; set; }
        public string OIDCClientId { get; set; }
        public string OIDCDomainHint { get; set; }
        public string OIDCLoginHint { get; set; }
        public string OIDCMaxAge { get; set; }
        public string OIDCNonce { get; set; }
        public string OIDCPrompt { get; set; }
        public string OIDCResource { get; set; }
        public string OIDCscope { get; set; }
        public string ContextBuildNumber { get; set; }
        public string ContextCorrelationId { get; set; }
        public string ContextDateTimeInUtc { get; set; }
        public string ContextDeploymentMode { get; set; }
        public string ContextIPAddress { get; set; }
        public string CorrelationId { get; set; }
    }
}
