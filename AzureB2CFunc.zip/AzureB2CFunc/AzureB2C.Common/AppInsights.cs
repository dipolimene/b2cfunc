﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using System.Collections.Generic;

namespace AzureB2C.Common
{
    public class AppInsights
    {
        public string InstrumentationKey { get; set; }

        public AppInsights(string instrumentationKey)
        {
            InstrumentationKey = instrumentationKey;
        }

        public void LogEvent(string eventName, InsightModel insightModel)
        {
            if (insightModel != null)
            {
                var telemetryConfiguration = TelemetryConfiguration.CreateDefault();
                telemetryConfiguration.InstrumentationKey = InstrumentationKey;
                var telemetryClient = new TelemetryClient(telemetryConfiguration);

                var properties = new Dictionary<string, string>
                {
                    { "RequestTraceId", insightModel?.RequestTraceId },
                    { "RequestId", insightModel?.RequestId },
                    { "CorrelationId", insightModel?.CorrelationId },
                    { "Culture", insightModel?.Culture },
                    { "FederatedUser", insightModel?.FederatedUser },
                    { "ParsedDomain", insightModel?.ParsedDomain },
                    { "Culture:LanguageName", insightModel?.CultureLanguageName },
                    { "Culture:LCID", insightModel?.CultureLCID },
                    { "Culture:RegionName", insightModel?.CultureRegionName },
                    { "Culture:RFC5646", insightModel?.CultureRFC5646 },
                    { "Policy:PolicyId", insightModel?.PolicyId },
                    { "Policy:RelyingPartyTenantId", insightModel?.PolicyRelyingPartyTenantId },
                    { "Policy:TenantObjectId", insightModel?.CorrelationId },
                    { "Policy:TrustFrameworkTenantId", insightModel?.PolicyTrustFrameworkTenantId },
                    { "OIDC:AuthenticationContextReferences", insightModel?.OIDCAuthenticationContextReferences },
                    { "OIDC:ClientId", insightModel?.OIDCClientId },
                    { "OIDC:DomainHint", insightModel?.OIDCDomainHint },
                    { "OIDC:LoginHint", insightModel?.OIDCLoginHint },
                    { "OIDC:MaxAge", insightModel?.OIDCMaxAge },
                    { "OIDC:Nonce", insightModel?.OIDCNonce },
                    { "OIDC:Prompt", insightModel?.OIDCPrompt },
                    { "OIDC:Resource", insightModel?.OIDCResource },
                    { "OIDC:scope", insightModel?.OIDCscope },
                    { "Context:BuildNumber", insightModel?.ContextBuildNumber },
                    { "Context:CorrelationId", insightModel?.ContextCorrelationId },
                    { "Context:DateTimeInUtc", insightModel?.ContextDateTimeInUtc },
                    { "Context:DeploymentMode", insightModel?.ContextDeploymentMode },
                    { "Context:IPAddress", insightModel?.ContextIPAddress }
                };

                telemetryClient.TrackEvent(eventName, properties);

                telemetryClient.Flush();
            }
        }
    }
}
