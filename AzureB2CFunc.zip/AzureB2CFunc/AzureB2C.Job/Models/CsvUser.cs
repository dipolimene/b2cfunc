﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace AzureB2C.Job.Models
{
    //first_name|last_name|email|phone|magento_email_verified|magento_phone_verified|pocs|country|magento_password_hash|magento_customer_id

    public class CsvUser
    {
        [Name("first_name")]
        public string FirstName { get; set; }

        [Name("last_name")]
        public string LastName { get; set; }

        [Name("email")]
        public string EmailAddress { get; set; }

        [Name("phone")]
        public string PhoneNumber { get; set; }

        [Name("magento_email_verified")]
        public bool EmailVerified { get; set; }

        [Name("magento_phone_verified")]
        public bool PhoneVerified { get; set; }

        [Name("pocs")]
        public string POC { get; set; }

        [Name("country")]
        public string Country { get; set; }

        [Name("magento_password_hash")]
        public string PasswordHash { get; set; }

        [Name("customer_id")]
        public string CustomerId { get; set; }
        
    }
}
