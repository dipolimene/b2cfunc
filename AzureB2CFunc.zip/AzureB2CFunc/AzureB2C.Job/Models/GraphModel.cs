﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace AzureB2C.Job.Models
{
    public class GraphCreateUserRequest
    {
        public bool accountEnabled { get; set; }
        public string creationType { get; set; }
        public string givenName { get; set; }
        public string surname { get; set; }
        public string displayName { get; set; }
        public string passwordPolicies { get; set; }
        public PasswordProfile passwordProfile { get; set; }
        public List<SignInName> signInNames { get; set; }
        public string country { get; set; }

        //public string extension_324e88e0f44b4f9685a522e117f1ea98_password_hash { get; set; }
        //public bool extension_324e88e0f44b4f9685a522e117f1ea98_isMigrated { get; set; }
        //public bool extension_324e88e0f44b4f9685a522e117f1ea98_magento_email_verified { get; set; }
        //public bool extension_324e88e0f44b4f9685a522e117f1ea98_magento_phone_verified { get; set; }
        //public string extension_324e88e0f44b4f9685a522e117f1ea98_pocs { get; set; }
        //public string extension_324e88e0f44b4f9685a522e117f1ea98_magento_customer_id { get; set; }

        public string extension_dcf61f48162b4937970afe245ee00aef_password_hash { get; set; }
        public bool extension_dcf61f48162b4937970afe245ee00aef_isMigrated { get; set; }
        public bool extension_dcf61f48162b4937970afe245ee00aef_magento_email_verified { get; set; }
        public bool extension_dcf61f48162b4937970afe245ee00aef_magento_phone_verified { get; set; }
        //public string extension_dcf61f48162b4937970afe245ee00aef_pocs { get; set; }
        public string extension_dcf61f48162b4937970afe245ee00aef_accountids { get; set; }
        public string extension_dcf61f48162b4937970afe245ee00aef_magento_customer_id { get; set; }

        //public string extension_550d6f9709d547a5ab7aef032227c4f6_password_hash { get; set; }
        //public bool extension_550d6f9709d547a5ab7aef032227c4f6_isMigrated { get; set; }
        //public bool extension_550d6f9709d547a5ab7aef032227c4f6_magento_email_verified { get; set; }
        //public bool extension_550d6f9709d547a5ab7aef032227c4f6_magento_phone_verified { get; set; }
        ////public string extension_550d6f9709d547a5ab7aef032227c4f6_pocs { get; set; }
        //public string extension_550d6f9709d547a5ab7aef032227c4f6_accountids { get; set; }
        //public string extension_550d6f9709d547a5ab7aef032227c4f6_magento_customer_id { get; set; }
    }

    public class PasswordProfile
    {
        public object password { get; set; }
        public bool forceChangePasswordNextLogin { get; set; }
        public bool enforceChangePasswordPolicy { get; set; }
    }

    public class SignInName
    {
        public string type { get; set; }
        public string value { get; set; }
    }

    public class GraphCreateUserResponse
    {
        public string objectType { get; set; }
        public string objectId { get; set; }
        public object deletionTimestamp { get; set; }
        public bool accountEnabled { get; set; }
        public object ageGroup { get; set; }
        public List<object> assignedLicenses { get; set; }
        public List<object> assignedPlans { get; set; }
        public object city { get; set; }
        public object companyName { get; set; }
        public object consentProvidedForMinor { get; set; }
        public object country { get; set; }
        public object createdDateTime { get; set; }
        public string creationType { get; set; }
        public object department { get; set; }
        public object dirSyncEnabled { get; set; }
        public string displayName { get; set; }
        public object employeeId { get; set; }
        public object facsimileTelephoneNumber { get; set; }
        public string givenName { get; set; }
        public object immutableId { get; set; }
        public object isCompromised { get; set; }
        public object jobTitle { get; set; }
        public object lastDirSyncTime { get; set; }
        public object legalAgeGroupClassification { get; set; }
        public object mail { get; set; }
        public string mailNickname { get; set; }
        public object mobile { get; set; }
        public object onPremisesDistinguishedName { get; set; }
        public object onPremisesSecurityIdentifier { get; set; }
        public List<object> otherMails { get; set; }
        public string passwordPolicies { get; set; }
        public PasswordProfile passwordProfile { get; set; }
        public object physicalDeliveryOfficeName { get; set; }
        public object postalCode { get; set; }
        public object preferredLanguage { get; set; }
        public List<object> provisionedPlans { get; set; }
        public List<object> provisioningErrors { get; set; }
        public List<object> proxyAddresses { get; set; }
        public DateTime refreshTokensValidFromDateTime { get; set; }
        public object showInAddressList { get; set; }
        public List<SignInName> signInNames { get; set; }
        public object sipProxyAddress { get; set; }
        public object state { get; set; }
        public object streetAddress { get; set; }
        public string surname { get; set; }
        public object telephoneNumber { get; set; }
    }

    public class GraphLoginResponse
    {
        public string token_type { get; set; }
        public string expires_in { get; set; }
        public string ext_expires_in { get; set; }
        public string expires_on { get; set; }
        public string not_before { get; set; }
        public string resource { get; set; }
        public string access_token { get; set; }
    }
}
