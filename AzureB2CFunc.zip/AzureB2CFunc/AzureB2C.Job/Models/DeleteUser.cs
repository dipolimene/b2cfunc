﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace AzureB2C.Job.Models
{
    public class GraphDeleteUserResponseModel
    {
        public GraphDeleteUserResponseModel()
        {
            value = new List<Value>();
        }
        [DataMember(Name = "odata.metadata")]
        public string ODataMetadata { get; set; }
        [DataMember(Name = "odata.nextLink")]
        public string ODataNextLink { get; set; }
        public List<Value> value { get; set; }
    }

    public class Value
    {
        public Value()
        {
            userIdentities = new List<UserIdentity>();
        }
        public string objectId { get; set; }
        public string displayName { get; set; }
        public string givenName { get; set; }
        public string surname { get; set; }
        public string userPrincipalName { get; set; }
        public string creationType { get; set; }
        //public bool extension_dcf61f48162b4937970afe245ee00aef_isMigrated { get; set; } //ABI_Dev
        //public bool extension_324e88e0f44b4f9685a522e117f1ea98_isMigrated { get; set; } //Qbit
        //public bool extension_5d3d99e7485f4d2ba45e388e0f7502e2_isMigrated { get; set; }//ABI_UAT
        public bool extension_678eb6093fc2452fa0c4a0b9fc487e32_isMigrated { get; set; }//ABI_SIT
        public List<UserIdentity> userIdentities { get; set; }
    }
    public class UserIdentity
    {
        public string issuer { get; set; }
        public string issuerUserId { get; set; }
    }

    public class DeleteCsvUser
    {
        public string objectId { get; set; }
        public string displayName { get; set; }
        public string givenName { get; set; }
        public string surname { get; set; }
        public string userPrincipalName { get; set; }
        public string creationType { get; set; }
        public string issuer { get; set; }
        public bool isMigrated { get; set; }
        public bool isSuccess { get; set; }
        public string Message { get; set; }
    }
}
