﻿using AzureB2C.Job.Formatter;
using AzureB2C.Job.Models;
using AzureB2C.Job.Tools;
using AzureB2C.TableStorage;
using CsvHelper;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureB2C.Job
{
    public class Worker
    {
        public string DataAzureTableStorageConnectionString { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public Stream BlobStream { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string TenantUrl { get; set; }
        public string MigrationJobStatusId { get; set; }
        public HttpClientService<GraphLoginResponse> tenantClientService { get; set; }
        public HttpClientService<string> graphClientService { get; set; }
        public string MigrationAppId { get; set; }

        public Worker()
        {
        }

        public void Run()
        {
            tenantClientService = new HttpClientService<GraphLoginResponse>(TenantUrl);
            graphClientService = new HttpClientService<string>("https://graph.windows.net/");

            var formatter = new DataFormatter();
            //Set Pending Status before job start
            var migrationJobStatus = new MigrationJobStatus(new Dictionary<string, string>()
            {
                { "DataAzureTableStorageConnectionString",DataAzureTableStorageConnectionString }
            });

            var migrationJobStatusDetails = new MigrationJobStatusDetails(new Dictionary<string, string>()
            {
                { "DataAzureTableStorageConnectionString",DataAzureTableStorageConnectionString }
            });

            var migrationJobStatusId = migrationJobStatus.CreateMigrationJobStatus(FileName, FilePath, "Pending");
            MigrationJobStatusId = migrationJobStatusId;
            try
            {
                //var csvUsers = LoadCsvFile();
                var csvUsers = LoadPipeCsvFile();
                migrationJobStatus.UpdateMigrationJobStatus(migrationJobStatusId, "InProgress");
                //using (var rateLimit = new RateLimit(1, new TimeSpan(0, 0, 2)))
                //{
                //foreach (var csvUser in csvUsers)
                //{

                Parallel.ForEach(csvUsers, (csvUser) =>
                {
                    string inputJson = string.Empty;
                    AzureGraphRespone azureGraphRespone = new AzureGraphRespone();
                    string objectId = string.Empty;
                    string magentoCustomerId = string.Empty;
                    string status = string.Empty;
                    try
                    {
                        inputJson = formatter.Serialize<CsvUser>(csvUser);
                        azureGraphRespone = CreateB2CUserV2(csvUser);
                        var createdGraphUser = formatter.Deserialize<GraphCreateUserResponse>(azureGraphRespone.OutputJson);
                        if (createdGraphUser != null && !string.IsNullOrWhiteSpace(createdGraphUser.objectId))
                        {
                            objectId = createdGraphUser.objectId;
                            magentoCustomerId = csvUser.CustomerId;
                            status = "Success";
                        }
                        else
                        {
                            status = "Error";
                        }
                        migrationJobStatusDetails.CreateMigrationJobStatusDetails(migrationJobStatusId,
                            inputJson, azureGraphRespone.OutputJson, status, objectId, magentoCustomerId, azureGraphRespone.Message,
                             azureGraphRespone.IsPhoneNormalized, azureGraphRespone.PhoneNumberFormat);
                        //rateLimit.WaitToProceed();
                    }
                    catch (Exception ex)
                    {
                        migrationJobStatusDetails.CreateMigrationJobStatusDetails(migrationJobStatusId, inputJson, azureGraphRespone.OutputJson, "Error", objectId, magentoCustomerId, $"Message :- { ex.Message} \n Inner Exception:- { ex.InnerException}");
                    }
                });


                //}
                //}
                migrationJobStatus.UpdateMigrationJobStatus(migrationJobStatusId, "Done");
            }
            catch (Exception ex)
            {
                migrationJobStatus.UpdateMigrationJobStatus(migrationJobStatusId, "Error", $"Message :- { ex.Message} \n Inner Exception:- { ex.InnerException}");
            }
            finally
            {
                graphClientService.Dispose();
            }
        }

        private List<CsvUser> LoadCsvFile()
        {
            List<CsvUser> csvUser;
            var reader = new StreamReader(BlobStream);
            using (var csv = new CsvReader(reader))
            {
                csvUser = csv.GetRecords<CsvUser>().ToList();
            }
            return csvUser;
        }

        public List<CsvUser> LoadPipeCsvFile()
        {
            List<CsvUser> csvUser = new List<CsvUser>();

            using (var reader = new StreamReader(BlobStream, Encoding.GetEncoding("iso-8859-1")))
            {
                string line;
                int index = 0;
                while ((line = reader.ReadLine()) != null)
                {
                    if (index > 0)
                    {
                        var lineArray = line.Split('|').ToArray();
                        csvUser.Add(new CsvUser()
                        {
                            FirstName = lineArray[0],
                            LastName = lineArray[1],
                            EmailAddress = lineArray[2],
                            PhoneNumber = lineArray[3],
                            EmailVerified = lineArray[4] == "1" ? true : false,
                            PhoneVerified = lineArray[5] == "1" ? true : false,
                            POC = lineArray[6],
                            Country = lineArray[7],
                            PasswordHash = lineArray[8],
                            CustomerId = lineArray[9]
                        });
                    }
                    index++;
                }
            }

            return csvUser;
        }

        private AzureGraphRespone CreateB2CUserV2(CsvUser csvUser)
        {
            var azureGraphRespone = new AzureGraphRespone();
            GraphLoginResponse graphLoginResponse = null;
            string phone = string.Empty;

            var requestFormParams = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("grant_type", "client_credentials"),
                new KeyValuePair<string, string>("client_id", ClientId),
                new KeyValuePair<string, string>("client_secret", ClientSecret),
                new KeyValuePair<string, string>("resource", "https://graph.windows.net")
            };

            graphLoginResponse = tenantClientService.PostAPI("oauth2/token", null, formParameters: requestFormParams);

            if (graphLoginResponse != null)
            {
                var signInNames = new List<SignInName>();

                azureGraphRespone.IsPhoneNormalized = "false";
                if (!string.IsNullOrWhiteSpace(csvUser.PhoneNumber))
                {
                    phone = csvUser.PhoneNumber;
                    if (csvUser.PhoneNumber.Contains("+"))
                    {
                        azureGraphRespone.IsPhoneNormalized = "true";
                    }
                }
                //
                csvUser.PhoneNumber = csvUser.PhoneNumber.ToNormalizePhoneNumber();
                csvUser.POC = csvUser.POC.ToRemoveWhiteSpace();
                azureGraphRespone.PhoneNumberFormat = string.Empty;
                if (!string.IsNullOrWhiteSpace(csvUser.PhoneNumber))
                {
                    azureGraphRespone.PhoneNumberFormat = $"phone:{phone } normalizedPhone:{csvUser.PhoneNumber}";
                }

                if (!string.IsNullOrWhiteSpace(csvUser.EmailAddress))
                {
                    if (csvUser.EmailAddress.ToLowerInvariant() != "null")
                    {
                        signInNames.Add(new SignInName() { type = "emailAddress", value = csvUser.EmailAddress });
                    }
                }
                if (!string.IsNullOrWhiteSpace(csvUser.PhoneNumber))
                {
                    if (csvUser.PhoneNumber.ToLowerInvariant() != "null")
                    {
                        //if (csvUser.PhoneNumber.ToValidateWithTwilio())
                        {
                            signInNames.Add(new SignInName() { type = "phoneNumber", value = csvUser.PhoneNumber });
                        }
                        //else
                        //{
                        //    throw new Exception("Twilio saying phone no is not valid");
                        //}
                    }
                }

                if (signInNames == null || signInNames.Count == 0)
                {
                    throw new Exception("either email or phone are required");
                }

                if (string.IsNullOrWhiteSpace(csvUser.POC))
                {
                    throw new Exception("accountid (pocs) are required");
                }

                if (csvUser.POC.Length > 254)
                {
                    azureGraphRespone.Message = "Info: accountid (pocs) are not more than 256 characters, record insert with first 4 POCs only";
                    csvUser.POC = string.Join(',', csvUser.POC.Split(',').Select(x => x.Trim()).ToList().Take(4));
                }

                if (!csvUser.EmailVerified && !csvUser.PhoneVerified)
                {
                    throw new Exception("Only verified email or phone are valid");
                }
                else if (!csvUser.EmailVerified)
                {
                    var emailSignIn = signInNames.Where(x => x.type == "emailAddress").FirstOrDefault();
                    if (emailSignIn != null)
                    {
                        signInNames.Remove(emailSignIn);
                    }

                    if (signInNames == null || signInNames.Count == 0)
                    {
                        throw new Exception("Only verified email or phone are valid");
                    }
                }
                else if (!csvUser.PhoneVerified)
                {
                    var phoneSignIn = signInNames.Where(x => x.type == "phoneNumber").FirstOrDefault();
                    if (phoneSignIn != null)
                    {
                        signInNames.Remove(phoneSignIn);
                    }

                    if (signInNames == null || signInNames.Count == 0)
                    {
                        throw new Exception("Only verified email or phone are valid");
                    }
                }
                /**
                // string appid, configuration 
                //var graphCreateUserRequest = new GraphCreateUserRequest()
                //{
                //    accountEnabled = true,
                //    creationType = "LocalAccount",
                //    givenName = csvUser.FirstName,
                //    surname = csvUser.LastName,
                //    displayName = $"{csvUser.FirstName} {csvUser.LastName}",
                //    passwordPolicies = "DisablePasswordExpiration, DisableStrongPassword",
                //    passwordProfile = new PasswordProfile() { password = "password@123", forceChangePasswordNextLogin = true, enforceChangePasswordPolicy = false },
                //    signInNames = signInNames,
                //    country = csvUser.Country,

                //    //Qbit
                //    //extension_324e88e0f44b4f9685a522e117f1ea98_password_hash = csvUser.PasswordHash,
                //    //extension_324e88e0f44b4f9685a522e117f1ea98_isMigrated = false,
                //    //extension_324e88e0f44b4f9685a522e117f1ea98_magento_email_verified = csvUser.EmailVerified,
                //    //extension_324e88e0f44b4f9685a522e117f1ea98_magento_phone_verified = csvUser.PhoneVerified,
                //    //extension_324e88e0f44b4f9685a522e117f1ea98_pocs = csvUser.POC,
                //    //extension_324e88e0f44b4f9685a522e117f1ea98_magento_customer_id = csvUser.CustomerId

                //    //ABI Dev
                //    extension_dcf61f48162b4937970afe245ee00aef_password_hash = csvUser.PasswordHash,
                //    extension_dcf61f48162b4937970afe245ee00aef_isMigrated = false,
                //    extension_dcf61f48162b4937970afe245ee00aef_magento_email_verified = csvUser.EmailVerified,
                //    extension_dcf61f48162b4937970afe245ee00aef_magento_phone_verified = csvUser.PhoneVerified,
                //    extension_dcf61f48162b4937970afe245ee00aef_accountids = csvUser.POC,
                //    extension_dcf61f48162b4937970afe245ee00aef_magento_customer_id = csvUser.CustomerId

                //    //ABI Prods                    
                //    //extension_550d6f9709d547a5ab7aef032227c4f6_password_hash = csvUser.PasswordHash,
                //    //extension_550d6f9709d547a5ab7aef032227c4f6_isMigrated = false,
                //    //extension_550d6f9709d547a5ab7aef032227c4f6_magento_email_verified = csvUser.EmailVerified,
                //    //extension_550d6f9709d547a5ab7aef032227c4f6_magento_phone_verified = csvUser.PhoneVerified,
                //    //extension_550d6f9709d547a5ab7aef032227c4f6_accountids = csvUser.POC,
                //    //extension_550d6f9709d547a5ab7aef032227c4f6_magento_customer_id = csvUser.CustomerId
                //};

                //var formatter = new DataFormatter();
                //var jsonResponse = formatter.Serialize<GraphCreateUserRequest>(graphCreateUserRequest);
                */


                var json = @"{
                      'accountEnabled': false,
                      'creationType': null,
                      'givenName': null,
                      'surname': null,
                      'displayName': null,
                      'passwordPolicies': 'DisablePasswordExpiration, DisableStrongPassword',
                      'passwordProfile': {
                            'password': 'Password1',
                            'forceChangePasswordNextLogin': true,
                            'enforceChangePasswordPolicy': false
                        },
                      'signInNames':[],
                      'country': 'null',
                      'extension_#migrationAppId_password_hash': '#passwordHash',
                      'extension_#migrationAppId_isMigrated': false,
                      'extension_#migrationAppId_magento_email_verified': #magento_email_verified,
                      'extension_#migrationAppId_magento_phone_verified': #magento_phone_verified,
                      'extension_#migrationAppId_accountids': '#accountdIds',
                      'extension_#migrationAppId_magento_customer_id': '#magentoId'
                    }";
                var data = json.Replace("#migrationAppId", MigrationAppId);
                data = data.Replace("#passwordHash", csvUser.PasswordHash);
                data = data.Replace("#accountdIds", csvUser.POC);
                data = data.Replace("#magentoId", csvUser.CustomerId);

                if (csvUser.EmailVerified)
                {
                    data = data.Replace("#magento_email_verified", "true");
                }
                else
                {
                    data = data.Replace("#magento_email_verified", "false");
                }

                if (csvUser.PhoneVerified)
                {
                    data = data.Replace("#magento_phone_verified", "true");
                }
                else
                {
                    data = data.Replace("#magento_phone_verified", "false");
                }



                dynamic d = JsonConvert.DeserializeObject(data);
                d.signInNames = JArray.Parse(JsonConvert.SerializeObject(signInNames));
                d.accountEnabled = true;
                d.creationType = "LocalAccount";
                d.givenName = csvUser.FirstName;
                d.surname = csvUser.LastName;
                d.country = csvUser.Country;
                d.displayName = $"{csvUser.FirstName} {csvUser.LastName}";
                var jsonResponse = JsonConvert.SerializeObject(d);

                var headerParams = new List<KeyValuePair<string, string>>
                {
                    new KeyValuePair<string, string>("Authorization", $"{ graphLoginResponse.access_token}"),
                };
                var graphCreateUserResponse = graphClientService.PostAPIReturnJsonResponse("myorganization/users?api-version=1.6", null, jsonResponse, headerParams);
                azureGraphRespone.OutputJson = graphCreateUserResponse;
            }

            return azureGraphRespone;
        }

        //private string CreateB2CUserV1(CsvUser csvUser)
        //{
        //    GraphLoginResponse graphLoginResponse = null;
        //    string outputJson = string.Empty;

        //    using (var clientService = new HttpClientService<GraphLoginResponse>(TenantUrl))
        //    {
        //        var requestFormParams = new List<KeyValuePair<string, string>>
        //        {
        //            new KeyValuePair<string, string>("grant_type", "client_credentials"),
        //            new KeyValuePair<string, string>("client_id", ClientId),
        //            new KeyValuePair<string, string>("client_secret", ClientSecret),
        //            new KeyValuePair<string, string>("resource", "https://graph.windows.net")
        //        };
        //        graphLoginResponse = clientService.PostAPI("oauth2/token", null, formParameters: requestFormParams);
        //    }

        //    if (graphLoginResponse != null)
        //    {
        //        var signInNames = new List<SignInName>();

        //        if (!string.IsNullOrWhiteSpace(csvUser.EmailAddress))
        //        {
        //            if (csvUser.EmailAddress.ToLowerInvariant() != "null")
        //            {
        //                signInNames.Add(new SignInName() { type = "emailAddress", value = csvUser.EmailAddress });
        //            }
        //        }
        //        if (!string.IsNullOrWhiteSpace(csvUser.PhoneNumber))
        //        {
        //            if (csvUser.PhoneNumber.ToLowerInvariant() != "null")
        //            {
        //                signInNames.Add(new SignInName() { type = "phoneNumber", value = csvUser.PhoneNumber });
        //            }
        //        }

        //        if (signInNames == null || signInNames.Count == 0)
        //        {
        //            throw new Exception("either email or phone are required");
        //        }

        //        if (string.IsNullOrWhiteSpace(csvUser.POC))
        //        {
        //            throw new Exception("accountid (pocs) are required");
        //        }

        //        var graphCreateUserRequest = new GraphCreateUserRequest()
        //        {
        //            accountEnabled = true,
        //            creationType = "LocalAccount",
        //            givenName = csvUser.FirstName,
        //            surname = csvUser.LastName,
        //            displayName = $"{csvUser.FirstName} {csvUser.LastName}",
        //            passwordPolicies = "DisablePasswordExpiration, DisableStrongPassword",
        //            passwordProfile = new PasswordProfile() { password = "password@123", forceChangePasswordNextLogin = true, enforceChangePasswordPolicy = false },
        //            signInNames = signInNames,
        //            country = csvUser.Country,

        //            //extension_324e88e0f44b4f9685a522e117f1ea98_password_hash = csvUser.PasswordHash,
        //            //extension_324e88e0f44b4f9685a522e117f1ea98_isMigrated = false,
        //            //extension_324e88e0f44b4f9685a522e117f1ea98_magento_email_verified = csvUser.EmailVerified,
        //            //extension_324e88e0f44b4f9685a522e117f1ea98_magento_phone_verified = csvUser.PhoneVerified,
        //            //extension_324e88e0f44b4f9685a522e117f1ea98_pocs = csvUser.POC,
        //            //extension_324e88e0f44b4f9685a522e117f1ea98_magento_customer_id = csvUser.CustomerId

        //            extension_dcf61f48162b4937970afe245ee00aef_password_hash = csvUser.PasswordHash,
        //            extension_dcf61f48162b4937970afe245ee00aef_isMigrated = false,
        //            extension_dcf61f48162b4937970afe245ee00aef_magento_email_verified = csvUser.EmailVerified,
        //            extension_dcf61f48162b4937970afe245ee00aef_magento_phone_verified = csvUser.PhoneVerified,
        //            extension_dcf61f48162b4937970afe245ee00aef_accountids = csvUser.POC,
        //            extension_dcf61f48162b4937970afe245ee00aef_magento_customer_id = csvUser.CustomerId
        //        };

        //        var formatter = new DataFormatter();
        //        var jsonResponse = formatter.Serialize<GraphCreateUserRequest>(graphCreateUserRequest);
        //        var headerParams = new List<KeyValuePair<string, string>>
        //        {
        //            new KeyValuePair<string, string>("Authorization", $"Bearer { graphLoginResponse.access_token}"),
        //        };
        //        //using (var clientService = new HttpClientService<GraphCreateUserResponse>("https://graph.windows.net/"))
        //        //{
        //        //    var graphCreateUserResponse = clientService.PostAPI("myorganization/users?api-version=1.6", null, jsonResponse, headerParams);

        //        //    outputJson = formatter.Serialize<GraphCreateUserResponse>(graphCreateUserResponse);
        //        //}
        //        using (var clientService = new HttpClientService<string>("https://graph.windows.net/"))
        //        {
        //            var graphCreateUserResponse = clientService.PostAPIReturnJsonResponse("myorganization/users?api-version=1.6", null, jsonResponse, headerParams);

        //            outputJson = graphCreateUserResponse;
        //        }
        //    }

        //    return outputJson;
        //}
    }

    public class AzureGraphRespone
    {

        public AzureGraphRespone()
        {
            Message = "";
        }

        public string OutputJson { get; set; }
        public string IsPhoneNormalized { get; set; }
        public string PhoneNumberFormat { get; set; }
        public string Message { get; set; }
    }
}
