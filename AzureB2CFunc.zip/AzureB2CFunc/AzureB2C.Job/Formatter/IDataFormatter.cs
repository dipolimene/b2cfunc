﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AzureB2C.Job.Formatter
{
    public interface IDataFormatter
    {
        T Deserialize<T>(string serializeData);

        string Serialize<T>(T entity);

        dynamic Deserialize(string deSerializeData, Type t);

        string SerializeXML<T>(T entity);
    }
}
