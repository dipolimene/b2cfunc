﻿using ServiceStack;
using System;
using System.Collections.Generic;
using System.Text;

namespace AzureB2C.Job.Formatter
{
    public class DataFormatter : IDataFormatter
    {
        public dynamic Deserialize(string deSerializeData, Type t)
        {
            throw new NotImplementedException();
        }

        public T Deserialize<T>(string serializeData)
        {
            try
            {
                return serializeData.FromJson<T>();
            }
            catch
            {
                return default(T);
            }
        }

        public string Serialize<T>(T entity)
        {
            try
            {
                return entity.ToJson();
            }
            catch
            {
                return string.Empty;
            }
        }

        public string SerializeXML<T>(T entity)
        {
            var serializer = new System.Xml.Serialization.XmlSerializer(entity.GetType(), string.Empty);
            var stringBuilder = new System.Text.StringBuilder();
            using (var stringWriter = new System.IO.StringWriter())
            {
                serializer.Serialize(stringWriter, entity);
                stringBuilder.Append(stringWriter);
            }
            String xmlizedString = stringBuilder.ToString();
            xmlizedString = xmlizedString.Replace("﻿<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
            xmlizedString = xmlizedString.Replace(" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"", "");
            xmlizedString = xmlizedString.Replace("xsi:nil=\"true\"", "");
            return xmlizedString;
        }
    }
}
