﻿using PhoneNumbers;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Twilio;
using Twilio.Rest.Lookups.V1;
using System.Linq;

namespace AzureB2C.Job.Tools
{
    public static class ExtensionsUtilis
    {
        public static string ToRemoveWhiteSpace(this string POC)
        {
            string formattedPOC = string.Empty;
            if (!string.IsNullOrWhiteSpace(POC))
            {
                formattedPOC = $"[{string.Join(',', POC.Split(',').Select(x => x.Trim()).ToList())}]";
            }
            return formattedPOC;
        }

        public static string ToNormalizePhoneNumber(this string phoneNumber)
        {
            string normalizePhone = string.Empty;
            var util = PhoneNumberUtil.GetInstance();

            phoneNumber = Regex.Replace(phoneNumber, "[^+0-9]", "");
            phoneNumber = Regex.Replace(phoneNumber, " ", "");

            if (!string.IsNullOrWhiteSpace(phoneNumber))
            {
                if (phoneNumber.Length > 16)
                {
                    throw new Exception("Invalid Phone Number (Can't more than 15 digit)");
                }

                var number = util.Parse(phoneNumber, "US");
                util.Format(number, PhoneNumberFormat.E164);

                normalizePhone = $"+{ number.CountryCode  }{ number.NationalNumber}";

            }

            return normalizePhone;
        }

        public static bool ToValidateWithTwilio(this string normalizePhone)
        {
            bool isValid = true;

            try
            {

                const string accountSid = "AC2839e2cbab4e2f43941670dadcfdb0e5";
                const string authToken = "14bbac6303f9c349e70483b1ea056aad";

                TwilioClient.Init(accountSid, authToken);

                var twilioPhoneNumberFormat = PhoneNumberResource.Fetch(
                   pathPhoneNumber: new Twilio.Types.PhoneNumber(normalizePhone)
                );
            }
            catch
            {
                isValid = false;
            }

            return isValid;
        }
    }
}
