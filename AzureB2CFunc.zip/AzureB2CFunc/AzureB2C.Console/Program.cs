﻿using AzureB2C.Job.Models;
using AzureB2C.Job.Tools;
using CsvHelper;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.Serialization;

namespace AzureB2C.Console
{
    class Program
    {

        public static string TenantUrl { get; set; }
        public static string ClientId { get; set; }
        public static string ClientSecret { get; set; }

        static void Main(string[] args)
        {
            //TenantUrl = "https://login.microsoftonline.com/qbitkloudb2c.onmicrosoft.com/";
            //ClientId = "3d295c9a-fad1-4388-a9be-1624a6fe2102";
            //ClientSecret = "7T2naWjPJyjcRby0me32j+Fu6i7WMugVmqzD5Viaq5Q=";

            //ABI Dev
            //TenantUrl = "https://login.microsoftonline.com/b2biamgbusdev.onmicrosoft.com/";
            //ClientId = "77d0c20d-6260-4faa-ae87-3fe86c19629d";
            //ClientSecret = "9x3Z+nXCTwFiDxLiMTu6G5BmGjtjOhv+cybDaRXmoFU=";

            //ABI UAT
            //TenantUrl = "https://login.microsoftonline.com/b2biamgbusuat1.onmicrosoft.com/";
            //ClientId = "33d7e21f-a633-4793-968f-b29798473bb5";
            //ClientSecret = "tkSCJqU3TNuMlvjI6eJlqohPy7ChJfeHitagApVywzw=";

            //ABI SIT
            TenantUrl = "https://login.microsoftonline.com/b2biamgbussit1.onmicrosoft.com/";
            ClientId = "9620a5b3-344c-491e-854b-3497412d5a2a";
            ClientSecret = "4u6xQzJ5af19oEaEEzOwr0HCAnkyMvVa7YILU1xlsak=";


            GetAADUsers();
        }

        static void GetAADUsers()
        {
            try
            {
                GraphLoginResponse graphLoginResponse = null;

                using (var clientService = new HttpClientService<GraphLoginResponse>(TenantUrl))
                {
                    var requestFormParams = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("grant_type", "client_credentials"),
                        new KeyValuePair<string, string>("client_id", ClientId),
                        new KeyValuePair<string, string>("client_secret", ClientSecret),
                        new KeyValuePair<string, string>("resource", "https://graph.windows.net")
                    };
                    graphLoginResponse = clientService.PostAPI("oauth2/token", null, formParameters: requestFormParams);
                }

                if (graphLoginResponse != null)
                {
                    var headerParams = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("Authorization", $"Bearer { graphLoginResponse.access_token}"),
                    };

                    var deleteCsvUserList = new List<DeleteCsvUser>();

                    string token = string.Empty;
                    do
                    {
                        using (var clientService = new HttpClientService<GraphDeleteUserResponseModel>("https://graph.windows.net/"))
                        {

                            var requestParams = new List<KeyValuePair<string, string>>
                            {
                                new KeyValuePair<string, string>("api-version","1.6"),
                                new KeyValuePair<string, string>("$top","999")
                            };

                            if (!string.IsNullOrWhiteSpace(token))
                            {
                                int skipTokenIndex = token.IndexOf("=");
                                string skipToken = token.Substring(skipTokenIndex + 1, token.Length - skipTokenIndex - 1);
                                requestParams.Add(new KeyValuePair<string, string>("$skipToken", skipToken));
                            }

                            var graphUserResponseModel = clientService.GetAPI("myorganization/users", requestParams, headerParams);

                            if (graphUserResponseModel != null)
                            {
                                foreach (var item in graphUserResponseModel.value)
                                {

                                    if (!string.IsNullOrWhiteSpace(item.creationType))
                                    {
                                        //if (item.creationType.ToLowerInvariant() == "localaccount" && item.extension_dcf61f48162b4937970afe245ee00aef_isMigrated==false)
                                        {
                                            deleteCsvUserList.Add(new DeleteCsvUser()
                                            {
                                                objectId = item.objectId,
                                                displayName = item.displayName,
                                                givenName = item.givenName,
                                                surname = item.surname,
                                                userPrincipalName = item.userPrincipalName,
                                                creationType = item.creationType,
                                                issuer = (item.userIdentities != null && item.userIdentities.Count > 0) ? item.userIdentities[0].issuer : "",
                                                isMigrated = item.extension_678eb6093fc2452fa0c4a0b9fc487e32_isMigrated
                                            });
                                        }
                                    }
                                }
                                token = graphUserResponseModel.ODataNextLink;
                            }
                        }
                    }
                    while (!string.IsNullOrWhiteSpace(token));

                    if (deleteCsvUserList.Count > 0)
                    {
                        using (var writer = new StreamWriter(@"D:\file_sit.csv"))
                        using (var csv = new CsvWriter(writer))
                        {
                            csv.WriteRecords(deleteCsvUserList);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
            }
        }
    }
}